window.MOCRO_SETTINGS = {};
