// Configure your WhatsApp number here using the international format without + or spaces.
const WHATSAPP_NUMBER = '212XXXXXXXXX';
const products = [
  {id:1,name:'Ensemble Streetwear Junior',price:249,category:'streetwear',label:'NOUVEAU',image:'https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=700'},
  {id:2,name:'Hoodie Oversize Noir',price:189,category:'streetwear',label:'BEST-SELLER',image:'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=700'},
  {id:3,name:'Ensemble Sport Confort',price:219,category:'sport',label:'NOUVEAU',image:'https://images.unsplash.com/photo-1503944583220-79d8926ad5e2?w=700'},
  {id:4,name:'T-shirt Graphic Kids',price:99,category:'casual',label:'',image:'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=700'},
  {id:5,name:'Veste légère urbaine',price:299,category:'streetwear',label:'-20%',oldPrice:369,image:'https://images.unsplash.com/photo-1544923246-77307dd654cb?w=700'},
  {id:6,name:'Jogging Sport Junior',price:159,category:'sport',label:'',image:'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=700'},
  {id:7,name:'Sweat Casual Beige',price:179,category:'casual',label:'',image:'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=700'},
  {id:8,name:'Casquette Street',price:79,category:'streetwear',label:'PROMO',oldPrice:99,image:'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=700'}
];
const categories = [
  {name:'STREETWEAR',image:'https://images.unsplash.com/photo-1523398002811-999ca8dec234?w=700',key:'streetwear'},
  {name:'SPORT',image:'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=700',key:'sport'},
  {name:'CASUAL',image:'https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=700',key:'casual'},
  {name:'NOUVEAUTÉS',image:'https://images.unsplash.com/photo-1490367532201-b9bc1dc483f6?w=700',key:'new'}
];
const savedSettings={...(window.MOCRO_SETTINGS||{}),...JSON.parse(localStorage.getItem('mocroSettings')||'{}')};
if(Array.isArray(savedSettings.products))products.splice(0,products.length,...savedSettings.products);
if(Array.isArray(savedSettings.categories))categories.splice(0,categories.length,...savedSettings.categories);
if(savedSettings.texts){for(const [selector,value] of Object.entries(savedSettings.texts)){const node=document.querySelector(selector);if(node)node.textContent=value}}
if(savedSettings.images){for(const [selector,value] of Object.entries(savedSettings.images)){const node=document.querySelector(selector);if(node&&value){if(selector==='.hero-bg')node.style.backgroundImage=`linear-gradient(45deg, rgba(0,0,0,0.7), rgba(255,0,150,0.3)), url('${value}')`;else if(selector==='.promo-bg')node.style.backgroundImage=`linear-gradient(90deg,rgba(0,0,0,.8),rgba(0,0,0,.5)),url('${value}')`;else node.src=value}}}
if(savedSettings.whatsapp)document.querySelectorAll('a[href*="wa.me"]').forEach(a=>a.href=`https://wa.me/${savedSettings.whatsapp}`);
if(savedSettings.siteName){document.title=`${savedSettings.siteName} - Vêtements Garçons Tendance`;document.querySelectorAll('.logo,.footer-logo').forEach(logo=>{const words=savedSettings.siteName.trim().split(/\s+/);logo.querySelector('.logo-text').textContent=words.shift()||'';logo.querySelector('.logo-accent').textContent=words.join(' ')})}
let activeCategory='all', searchTerm='';
let cart=JSON.parse(localStorage.getItem('mocroCart')||'[]');
const productsGrid=document.querySelector('#productsGrid');
function renderProducts(){
  const shown=products.filter(p=>(activeCategory==='all'||(activeCategory==='new'?p.label==='NOUVEAU':activeCategory==='sale'?p.oldPrice: p.category===activeCategory))&&p.name.toLowerCase().includes(searchTerm.toLowerCase()));
  productsGrid.innerHTML=shown.length?shown.map(p=>`<article class="product-card"><div class="product-image"><img loading="lazy" src="${p.image}" alt="${p.name}">${p.label?`<span class="product-label">${p.label}</span>`:''}<button class="add-cart" data-add="${p.id}">AJOUTER AU PANIER</button></div><div class="product-info"><p class="product-name">${p.name}</p><div class="product-price">${p.price} DH ${p.oldPrice?`<del>${p.oldPrice} DH</del>`:''}</div></div></article>`).join(''):'<p class="no-products">Aucun article trouvé.</p>';
}
function renderCategories(){document.querySelector('#categoriesGrid').innerHTML=categories.map(c=>`<a class="cat-card" href="#shop" data-cat="${c.key}"><img loading="lazy" src="${c.image}" alt="${c.name}"><span>${c.name} →</span></a>`).join('')}
function saveCart(){localStorage.setItem('mocroCart',JSON.stringify(cart));renderCart()}
function renderCart(){const count=cart.reduce((n,i)=>n+i.qty,0),total=cart.reduce((n,i)=>n+i.price*i.qty,0);document.querySelector('.cart-count').textContent=count;document.querySelector('#cartItemsCount').textContent=count;document.querySelector('#cartTotal').textContent=`${total} DH`;document.querySelector('#cartItems').innerHTML=cart.length?cart.map(i=>`<div class="cart-row"><img src="${i.image}" alt=""><div><strong>${i.name}</strong><small>${i.qty} × ${i.price} DH</small></div><button class="remove-item" data-remove="${i.id}" aria-label="Supprimer">×</button></div>`).join(''):'<p class="empty-cart">Votre panier est vide</p>'}
function toggleCart(open){document.querySelector('#cartSidebar').classList.toggle('open',open);document.querySelector('#overlay').classList.toggle('visible',open)}
document.addEventListener('click',e=>{const add=e.target.closest('[data-add]');if(add){const p=products.find(x=>x.id===Number(add.dataset.add)),item=cart.find(x=>x.id===p.id);item?item.qty++:cart.push({...p,qty:1});saveCart();add.textContent='AJOUTÉ ✓';setTimeout(()=>add.textContent='AJOUTER AU PANIER',1000)}const remove=e.target.closest('[data-remove]');if(remove){cart=cart.filter(i=>i.id!==Number(remove.dataset.remove));saveCart()}const cat=e.target.closest('[data-cat]');if(cat){activeCategory=cat.dataset.cat;renderProducts()}const badge=e.target.closest('.badge-item');if(badge){activeCategory=badge.dataset.category;document.querySelectorAll('.badge-item').forEach(b=>b.classList.toggle('selected',b===badge));renderProducts()}if(e.target.closest('.cart-btn'))toggleCart(true);if(e.target.closest('.close-cart')||e.target.id==='overlay')toggleCart(false);if(e.target.closest('.hamburger'))document.querySelector('.nav-menu').classList.toggle('open');if(e.target.closest('.btn-hero'))document.querySelector('#shop').scrollIntoView({behavior:'smooth'});if(e.target.closest('.btn-promo')){activeCategory='sale';renderProducts();document.querySelector('#shop').scrollIntoView({behavior:'smooth'})}if(e.target.closest('.btn-checkout'))checkout()});
function checkout(){if(!cart.length){alert('Votre panier est vide.');return}const number=savedSettings.whatsapp||WHATSAPP_NUMBER;if(number.includes('X')){alert('Ajoutez votre numéro WhatsApp dans la page Administration.');return}const lines=cart.map(i=>`• ${i.name} x${i.qty} — ${i.price*i.qty} DH`).join('\n');const total=cart.reduce((n,i)=>n+i.price*i.qty,0);const message=encodeURIComponent(`Bonjour Mocro Shop, je souhaite commander :\n${lines}\n\nTotal : ${total} DH`);window.open(`https://wa.me/${number}?text=${message}`,'_blank','noopener')}
document.querySelector('.search-btn').addEventListener('click',()=>{let panel=document.querySelector('.search-panel');if(!panel){panel=document.createElement('div');panel.className='search-panel';panel.innerHTML='<div class="container"><input type="search" placeholder="Rechercher un article…" aria-label="Rechercher"></div>';document.querySelector('.navbar').after(panel);panel.querySelector('input').addEventListener('input',e=>{searchTerm=e.target.value;renderProducts();document.querySelector('#shop').scrollIntoView({behavior:'smooth'})})}panel.classList.toggle('open');if(panel.classList.contains('open'))panel.querySelector('input').focus()});
renderCategories();renderProducts();renderCart();
